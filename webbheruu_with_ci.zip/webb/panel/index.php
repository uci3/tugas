<?php
header("location:dash.php");